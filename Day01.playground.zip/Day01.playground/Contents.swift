/*
 Swift - est. 2014
 */

var name = "Ted" //variable
name = "Rebecca"
name = "Keeley"

let character = "Daphne" //constant
// use constants over vars if you can!

let actor = "John Doe"
let filename = "paris.jpg"
let quote = "The he tapped \"Believe\" and walked away" //use " within ""
let movie = """
A day in
the life of an
Apple engineer
"""
// multi line strings can be created by adding """ on single lines

//Length of a string:
print(actor.count)
print(character.uppercased())
// If we ask Switft to read data - don't use (), ask it to write - use ()

print(filename.hasPrefix("paris"))
print(filename.hasSuffix(".txt"))

let score = 10
let reallyBig = 100_000_000 //we use _ to add readability

let lowerScore = score - 2
let highetScore = score + 10

var counter = 10
counter = counter + 5
counter += 5 // compound assignment operator

let number = 120
print(number.isMultiple(of: 4))

//Decimal numbers are known as floating point numbers - float
//named that because computers are designed to store them similarly (0.001 = 1000) - only the decimal is moved

let numberToo = 0.1 + 0.2
print(numberToo) // prints 0.30000000000000004

let a = 1
let b = 2.0
//let c = a + b - THIS WONT WORK due to Type Safety. a is Int, b is Double, 2 different data types
let c = a + Int(b) // either make a a double or b an int

let double1 = 3.1
let double2 = 3131.3131
let double3 = 3.0
let int1 = 3
//TypeSafe = if a var has been set at Int it can't be something else

var rating = 5.0
rating *= 2 // compound assignment works

//Double and CGFloat can be used together
